const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();
const PORT = 8081;

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/loginform', { useNewUrlParser: true, useUnifiedTopology: true });
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => console.log('Connected to MongoDB'));

// Define a Mongoose schema and model
const userSchema = new mongoose.Schema({
  name:String,
  username:String,
  position:String,
  email: String,
  password: String
});
const User = mongoose.model('User', userSchema);

// Middleware
app.use(bodyParser.json());

// POST route to save user data
app.post('/data', (req, res) => {
  const {name,username,position, email, password } = req.body;
  const newUser = new User({ name,username,position,email, password });
  newUser.save((err, savedUser) => {
    if (err) {
      console.error('Error saving user data:', err);
      res.status(500).json({ error: 'Failed to save user data' });
    } else {
      console.log('User data saved:', savedUser);
      res.json({ message: 'User data saved successfully' });
    }
  });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
